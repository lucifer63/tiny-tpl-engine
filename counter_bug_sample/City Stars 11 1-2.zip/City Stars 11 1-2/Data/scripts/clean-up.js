$('*').each(function() {
	var $this = $( this ),
		classname = $this.attr('class'),
		first_class;

	if (classname) {
		first_class = classname.split(' ')[0];
		$this.attr('class', first_class);
	}
})