$("[rel='task'] p:not(:has([rel='image']))").each(function() {
	var $this = $( this );

	$this.attr('margin_top', '0');
});

$('[rel="task"]').each(function() {
	var $this = $( this ),
		$inner_tasks = $this.find('[rel="inner-task"]'),
		groups = [ $() ],
		$marker,
		$table,
		$current_group;

	$inner_tasks.each(function() {
		var $sibling = $( this ).next();

		if (!$sibling.is('[rel="inner-task"]') || !$sibling.length) {
			groups[groups.length] = $();
		}

		groups[groups.length - 1] = groups[groups.length - 1].add( $(this) );
	})

	if ($inner_tasks.length) {
		for (var i = 0; i < groups.length; i++) {
			$marker = $('<marker/>');
			$table = $('<table border-style="none" bgcolor="DFEEEE" width="100%"></table>');
			$current_group = groups[i];

			$current_group.first().before( $marker );
			$current_group.each(function() {
				$table.append($(this));
			});

			$marker.after( $table ).remove();
		}		
	}

	// old

	// $('[rel="task"]').each(function() {
	// 	var $this = $( this ),
	// 		$elements = $this.find('[rel="inner-task"]'),
	// 		$marker = $('<marker/>'),
	// 		$table = $('<table border-style="none" bgcolor="DFEEEE" width="100%"></table>');

	// 	if ($elements.length) {
	// 		$elements.first().before( $marker );

	// 		$elements.each(function() {
	// 			$table.append($(this));
	// 		});

	// 		$marker.after( $table ).remove();
	// 	}
	// });
});


$('[rel="task"] [rel="content"] > ul').each(function() {
	var $this = $( this ),
		$table = $('<table border-style="none" width="100%" margin_top="0"></table>'),
		$li = $this.find('li');

	if ($li.length) {
		$li.each(function() {
			$table.append($(
				`<tr>
					<td><sans>•&#160;&#160;</sans></td>
					<td><sans>${$( this ).text()}</sans></td>
				</tr>`
				))
		});

		$this.after( $table ).remove();

		$table.find('tr').eq(1).find('td').eq(1).attr('width','100%');
	}
});

/*
$('[rel="numbered-list"] [rel="content"]').each(function() {
	var $this = $( this ),
		$elements = $this.find('> li');

	$elements.each(function() {
		$this.append($(
			`<tr>
				<td><sans_b rel="counter"></sans_b></td>
				<td><sans>${$( this ).text()}</sans></td>
			</tr>`
		))
	});
})
*/

$('[rel="list"]').each(function() {
	var $this = $( this ),
		$trs = $this.find('> tr'),
		list_style_symbols = $this.attr('list-style-symbols'),
		current_symbol_index = 0;

	if (list_style_symbols && list_style_symbols.trim()) {
		list_style_symbols = list_style_symbols.split(/\s+/);
	} else {
		list_style_symbols = null;
	}

	$trs.each(function(i) {
		var counter_text = i;

		if (list_style_symbols) {
			if (!list_style_symbols[current_symbol_index]) {
				current_symbol_index = 0;
			}
			counter_text = list_style_symbols[current_symbol_index];
			current_symbol_index++;
		}

		$( this ).find('td').first().text(counter_text);
	})
});

$("[rel='inner-task']").each(function() {
	var $this = $( this ),
		$elements = $this.find('tr'),
		$marker = $('<marker/>'),
		$table = $('<table border-style="none" width="100%" margin_top="0" margin_bottom="0"></table>');

	if ($elements.length) {
		$elements.first().before( $marker );

		$elements.each(function() {
			$table.append($(this));
		});

		$marker.after( $table ).remove();
	}
})

$('[numbered] [rel="inner-task"]').each(function() {
	var $this = $( this );

	$this.parent().removeAttr('bgcolor');
	$this.each(function() {
		$( this ).find('> td').first().remove();
	})
});

$('[no-counter]').each(function() {
	$(this).find('[rel="counter"]').first().parent().remove()
})

$('variants').each(function() {
	var $this = $( this ),
		variants = $this.text(),
		$table = $('<table border-style="none" margin_top="0"></table>'),
		$row = $('<tr></tr>'),
		comma_reg = /\s*,\s*/,
		starting_charcode = 65;

	if(!variants.trim()) {
		throw new Error(`Element ${ $this.prop('tagName') } has invalid data!`);
	}

	variants = variants.split( comma_reg );

	if (variants.length) {
		$this.after($table).remove();
		$table.append( $row );

		variants.forEach(function(variant_content, i) {
			$row.append(
				`<td width="${ (100/variants.length).toFixed(4) }%">
					<sans_b>${ String.fromCharCode(starting_charcode + i) }</sans_b><sans> ${ variant_content }</sans>
				</td>`
				);
		});
	}
});

$('gaps').each(function() {
	var $this = $( this ),
		gaps = $this.text(),
		$table = $('<table></table>'),
		first_col = $this.attr('first-col'),
		comma_reg = /\s*,\s*/;

	if(!gaps.trim()) {
		throw new Error(`Element ${ $this.prop('tagName') } has invalid data!`);
	}

	gaps = gaps.split( comma_reg );
	if (first_col && first_col.trim()) {
		first_col = first_col.split( comma_reg );
	}

	var $first_row = $('<tr></tr>'),
		$second_row = $('<tr></tr>'),
		first_col_width = 1.5,
		td_width = 100/gaps.length;

	if (first_col && first_col.length === 2) {
		$first_row.append(`<td text-align="left" text-valign="center" bgcolor="ECECED" width="${ td_width * first_col_width }%"><sans_b>${ first_col[0] }</sans_b></td>`);
		$second_row.append(`<td text-align="left" text-valign="center"><sans_b>${ first_col[1] }</sans_b></td>`);
		td_width = (100 - td_width * first_col_width)/gaps.length;
	}

	$table
		.append($first_row)
		.append($second_row)
		.attr('border-color', 'A8A9AD')
		.attr('border-size', '2px');

	gaps.forEach(function(gap_content) {
		$first_row.append(`<td text-align="center" text-valign="center" bgcolor="ECECED" width="${ td_width.toFixed(4) }%"><sans_b>${ gap_content }</sans_b></td>`);
		$second_row.append('<td>&#160;</td>');
	})

	$this.after($table).remove();
});

$('[rel="text-with-matches"]').each(function() {
	var $this = $( this ),
		$first_cell = $this.find('tr').first().find('td').eq(0),
		$second_cell = $this.find('tr').first().find('td').eq(1),
		$second_cell_elements = $second_cell.find('> *'),
		$table = $(
			`<table border-color="4FFFFF" border-size="2px">
				<tr>
					<td text-align="left">
						<media_container padding_left="10px" padding_right="10px" padding_top="5px"></media_container>
					</td>
				</tr>
			</table>`
		),
		$container = $table.find('media_container'),
		p_counter = 0;

	$second_cell_elements.each(function(i) {
		var $this = $( this );

		if ($this.prop('tagName') === 'P') {
			$container.append( `<p><nobr><sans_b>${ ++p_counter }) ${ $(this).text() }</sans_b></nobr></p>` );	
			$this.remove();
		} else {
			$second_cell.append( $this );
		}
	})

	$first_cell.attr('modify-child-text-nodes', 'sans');
	if (!$second_cell.attr('text-valign')) {
		$second_cell.attr('text-valign', 'center');
	}
	if (!$second_cell.attr('text-align')) {
		$second_cell.attr('text-align', 'center');
	}
	$second_cell.append( $table );
})

$('[modify-text-nodes]').each(function() {
	var $this = $( this ),
		new_tag = $this.attr('modify-text-nodes');

	if (new_tag) {
		$this.eachTextNode( tagWrapper(new_tag) );
	}
});

$('[modify-child-text-nodes]').each(function() {
	var $this = $( this ),
		new_tag = $this.attr('modify-child-text-nodes');
	if (new_tag) {
		$this.find('> *').eachTextNode( tagWrapper(new_tag) )
	}
});

$('temp').each(function() {
	var $this = $( this ),
		$marker = $('<marker/>');

	$this.before( $marker );

	$marker.after( $this.children() );

	$this.remove();
	$marker.remove();
});

function tagWrapper(tagname) {
	return function() {
		if (this.data.trim()) {
			this.data = `<${tagname}>${this.data}</${tagname}>`;
		}
	} 
}