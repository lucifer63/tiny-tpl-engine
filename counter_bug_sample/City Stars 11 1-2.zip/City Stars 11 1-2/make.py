# -*- coding: utf-8 -*-
import codecs, glob, os, sys, argparse, shutil as st, subprocess as sp

def getVersion(releaseDir):
    finalVersion = 0
    dirName, subdirList, fileList = next(os.walk(releaseDir, topdown=True))
    for dir in reversed(subdirList):
        try:
            version = int(dir)
            if version > finalVersion:
                finalVersion = version
        except:
            continue
    return finalVersion

def callCharon(config):
    sp.call(['../Parser/Parser/Charon/x64/Release/Charon.exe', config])

def callFTS(config):
    sp.call(['../Parser/Parser/Hades/x64/Release/Hades.exe', config])

def callTex(articlesDir):
	articles = []
	for file in os.listdir(articlesDir):
		if '.xml' in file:
			articles.append(os.path.join(articlesDir, file))
	sp.call(["../Parser/Parser/FrontTexReplacer/Release/FrontTexReplacer.exe"]+ articles)


def cleanByExt(ext):
    for file in glob.glob('*'+ext):
        os.remove(file)

def buildDATF(project, version):
    id = ''
    with codecs.open(project, 'r', 'UTF-8') as sprojFile:
        while True:
            line = sprojFile.readline()
            if '<dictid>' in line.lower():
                id = line[line.find('>') + 1 : line.rfind('<')]
                break

    if id and version:
        with codecs.open(id+'.Version.xml', 'w', 'UTF-8') as versionFile:
            versionFile.writelines(['<DictionaryVersionInfo>',
                                    '   <MajorVersion>0</MajorVersion>',
                                    '   <MinorVersion>' + version + '</MinorVersion>',
                                    '   <BrandName>Slovoed</BrandName>',
                                    '</DictionaryVersionInfo>'])

    sp.call(['../Parser/Engine/Compiler.exe', project])

def copyOutput(outputDir):
    versionDir = os.path.join(outputDir, 'version')
    ftsDir = os.path.join(outputDir, 'fts')
    sprojDir = os.path.join(outputDir, 'sproj')
    logsDir = os.path.join(outputDir, 'logs')

    if not os.path.exists(outputDir):
        os.makedirs(outputDir)
        os.makedirs(versionDir)
        os.makedirs(ftsDir)
        os.makedirs(sprojDir)
        os.makedirs(logsDir)

    for file in os.listdir('.'):
        if '.datf' in file:
            st.copy2(file, outputDir)
        if '.Version.xml' in file:
            st.copy2(file, versionDir)
        if '_fts_' in file:
            st.copy2(file, ftsDir)
        if '.sproj' in file:
            st.copy2(file, sprojDir)
        if '.log' in file:
            st.copy2(file, logsDir)
        if file == 'Articles' or file == 'Lists' and os.path.isdir(file):
            st.copytree(file, os.path.join(outputDir, file))

def parseArguments(argv):
    parser = argparse.ArgumentParser(description='Build datf.')
    parser.add_argument('-v', '--version', type=int, help='datf version.')
    parser.add_argument('-r', '--releaseDir', help='figure out datf version from releaseDir. ignored if -v is used.')
    parser.add_argument('-o', '--outputDir', help='output directory. datf and sources will be copied there.')
    parser.add_argument('-t', '--tex', action='store_true', help='enable tex replacer.')
    parser.add_argument('-f', '--fts', action='store_true', default=True, help='enable fts generator.')
    return parser.parse_args(argv)

def main(argv):
    args = parseArguments(argv)

    version = '0'
    if args.version:
        version = str(args.version)
    elif args.releaseDir:
        version = str(getVersion(args.releaseDir))

    callCharon('Data/configs/config.cfg')
    if args.tex:
    	callTex('Articles')

    if args.fts:
    	callFTS('Data/configs/config.cfg')

    for project in glob.glob('*.sproj'):
        buildDATF(project, version)

    if args.outputDir:
        copyOutput(args.outputDir)
    elif args.releaseDir:
        outDirFinal = os.path.join(args.releaseDir, str(int(version)+1))
        copyOutput(outDirFinal)

if __name__=='__main__':
    main(sys.argv[1:])